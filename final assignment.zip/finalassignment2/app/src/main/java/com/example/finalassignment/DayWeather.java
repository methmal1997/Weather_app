package com.example.finalassignment;

public class DayWeather {
}
