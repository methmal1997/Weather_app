package com.example.finalassignment;

public class locate {
    String city;
    String country;
    Double lat;
    Double lon;

    public locate(String city, String country, Double lat, Double lon) {
        this.city = city;
        this.country = country;
        this.lat = lat;
        this.lon = lon;
    }
}
