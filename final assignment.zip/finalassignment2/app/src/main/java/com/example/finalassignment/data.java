package com.example.finalassignment;
public class data {

    public static String unit = "celsius";
    public static Double lat = 6.9319;
    public static Double lon = 79.8478;
    public static String city = "Colombo, LK";

}

